# YASAK Web (PWA) — versão inicial

## Como testar
1. Publique os arquivos desta pasta em um serviço de hospedagem estática com HTTPS (por exemplo, GitHub Pages, Netlify ou Vercel).
2. Abra o endereço publicado no Safari do iPhone.
3. Toque em Compartilhar > Adicionar à Tela de Início.

## O que já funciona
- Visão geral e meta patrimonial configurável.
- Pilares Empresarial, Particular e Investimentos.
- Cadastro e exclusão de lançamentos.
- Indicadores e alertas básicos.
- Projeção simples de aporte mensal.
- Armazenamento local no navegador e exportação JSON.
- Estrutura PWA com cache básico para uso offline após primeiro carregamento.

## Limitações importantes
Esta é uma versão de protótipo: não possui autenticação, banco de dados em nuvem, sincronização entre aparelhos, integração bancária, controle de acesso, nem cálculos de rentabilidade, impostos ou inflação. Os dados ficam no navegador do aparelho. Não usar como sistema contábil ou recomendação financeira.
